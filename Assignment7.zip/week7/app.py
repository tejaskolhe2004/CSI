import streamlit as st
import numpy as np
import pickle
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.datasets import load_iris

# Load trained model
model = pickle.load(open("iris_model.pkl", "rb"))
iris = load_iris()

st.title("🌸 Iris Species Predictor")

st.markdown("Enter the features of the flower to predict the species.")

# Input sliders
sepal_length = st.slider("Sepal Length (cm)", 4.0, 8.0, 5.1)
sepal_width = st.slider("Sepal Width (cm)", 2.0, 4.5, 3.5)
petal_length = st.slider("Petal Length (cm)", 1.0, 7.0, 1.4)
petal_width = st.slider("Petal Width (cm)", 0.1, 2.5, 0.2)

# Create base DataFrame
df = pd.DataFrame(iris.data, columns=iris.feature_names)
df["species"] = iris.target_names[iris.target]

# Predict button
if st.button("Predict"):
    input_data = np.array([[sepal_length, sepal_width, petal_length, petal_width]])
    prediction = model.predict(input_data)
    predicted_class = iris.target_names[prediction[0]]
    st.success(f"🌼 Predicted Species: **{predicted_class}**")

    # Add prediction as a new row to DataFrame
    new_row = {
        "sepal length (cm)": sepal_length,
        "sepal width (cm)": sepal_width,
        "petal length (cm)": petal_length,
        "petal width (cm)": petal_width,
        "species": predicted_class + " (You)"
    }

    df = pd.concat([df, pd.DataFrame([new_row])], ignore_index=True)

    st.subheader("📋 Updated Iris Dataset with Your Prediction")
    st.dataframe(df.tail(10))  # Show last 10 rows including your input

    # Plot with highlighted user input
    fig, ax = plt.subplots()
    sns.scatterplot(data=df[df["species"] != predicted_class + " (You)"],
                    x="sepal length (cm)", y="petal length (cm)", hue="species", ax=ax)
    ax.scatter(sepal_length, petal_length, color="black", s=100, label="Your Input", marker="X")
    plt.legend()
    st.pyplot(fig)

else:
    st.subheader("📊 Iris Dataset Overview")
    st.dataframe(df.head())

    # Default scatter plot
    fig, ax = plt.subplots()
    sns.scatterplot(data=df, x="sepal length (cm)", y="petal length (cm)", hue="species", ax=ax)
    st.pyplot(fig)
